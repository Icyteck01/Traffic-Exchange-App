/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package surfsharkserver;

/**
 *
 * @author DEV-RAYS
 */
public class cmd {
        public static final int cmd0 = 0;
        public static final int cmd1 = 1;
        public static final int cmd2 = 2;
}
