/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package surfsharkserver;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author DEV-RAYS
 */
public class IConfigs {
    public static int percentage0 = 70;
    public static int percentage1 = 100;
    public static int urlSlots = 5;
    public static Map<String, ArrayList<Long>> clients =  new HashMap<String, ArrayList<Long>>();
    public static long totalOnline = 0L;
    public static int clean_log_interval = 43200000;
}
