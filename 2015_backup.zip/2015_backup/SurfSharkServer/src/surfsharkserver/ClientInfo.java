/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package surfsharkserver;

/**
 *
 * @author DEV-RAYS
 */
/**
 *
 * ClientInfo class contains information about a client, connected to the server.
 */

import java.net.Socket;

public class ClientInfo
{
    public long userID=-1;
    public Socket mSocket = null;
    public String[] urls = null;
    public ClientListener mClientListener = null;
    public ClientSender mClientSender = null;
    public String InetIp = null;
    public int minutes = 0;
    public int surfed = 1;  
    public int type = 0;
    public int thisSesion = 0;
    public String[] viewed = null;
    public String loginHash = null;
    public String region = null;
    public String hwKey = null;
    public String UserName = null;
}
