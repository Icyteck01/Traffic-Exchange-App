/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package surfsharkserver.logger;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import surfsharkserver.logger.SingleLineFormatter;
import surfsharkserver.IConfigs;
/**
 *
 * @author DEV-RAYS
 */
public class Loger {
   public static final Logger logger = Logger.getLogger("syslog");  
   public FileHandler fh;
   public File f;
   public String path = "Logs"+File.separator+"system.log";
   
      public static Logger getLog(){        
          return logger;
      }
   
      public void init() throws IOException{
        f = new File(path);
        f.getParentFile().mkdirs(); 
        f.createNewFile();          
        fh = new FileHandler(path);
        logger.addHandler(fh);
        SingleLineFormatter formatter = new SingleLineFormatter();  
        fh.setFormatter(formatter);
        runner();
      }
      
      public void runner()
      {
        int interval = IConfigs.clean_log_interval;
        new Timer().schedule(new TimerTask() {        
            @Override
            public void run() {
              backuplog();      
            }
        }, interval);
      }
      public void backuplog(){
          try {
              Calendar calendar = Calendar.getInstance();
              java.util.Date now = calendar.getTime();
              java.sql.Timestamp currentTimestamp = new java.sql.Timestamp(now.getTime());      
              Files.copy(Paths.get(path), Paths.get(path+"_"+currentTimestamp.getTime()+".log"));
              logger.removeHandler(fh);
              fh.close();
              fh = new FileHandler(path);
              logger.addHandler(fh);              
              SingleLineFormatter formatter = new SingleLineFormatter();  
              fh.setFormatter(formatter);
              runner();
          } catch (IOException ex) {
              Logger.getLogger(Loger.class.getName()).log(Level.SEVERE, null, ex);
          }
      }
      
      public void loginfo(String msg) throws IOException{
        logger.info(msg);
      }     
}
