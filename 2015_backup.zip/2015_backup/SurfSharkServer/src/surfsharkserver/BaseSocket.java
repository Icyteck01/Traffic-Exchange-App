/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package surfsharkserver;

/**
 *
 * @author DEV-RAYS
 */
public class BaseSocket {
        public int module = -1;
        public int cmd = -1;
        public String time = "";
        public Object value = -1;
}
