/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package surfsharkserver;

/**
 *
 * @author DEV-RAYS
 */
public class SiteClass {
        public int id;
        public int uid;
        public String name;
        public String url;
        public String refurl;
        public int time;
        public String click;
        public int state;  
        public String region = null;
}
