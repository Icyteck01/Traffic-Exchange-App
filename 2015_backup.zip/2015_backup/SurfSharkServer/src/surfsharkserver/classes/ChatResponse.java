/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package surfsharkserver.classes;

/**
 *
 * @author DEV-RAYS
 */
public class ChatResponse {
    public int MessageID = 0;
    public String UserName = "";
    public String Posted = "";
    public String Message = "";
}
