/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package surfsharkserver.classes;

/**
 *
 * @author DEV-RAYS
 */
public class LoginInfo {

        public String username = "";
        public String password = "";
        public String hardwereKey = "";
        public String country = "";
}
