/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package surfsharkserver.classes;

/**
 *
 * @author DEV-RAYS
 */
public class DefaultResponse {
   public long value = -1;
   public String message = "";
   public int minutes = 0;
   public int surfed = 0;
   public String link = "";
   public String referelink = "";
   public int seconds = 10;
   public int type = 0;
   public long uid = 0;
   public String region = "";
   public String regions = null;
}
