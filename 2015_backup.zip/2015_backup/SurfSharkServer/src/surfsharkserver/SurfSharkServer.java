/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package surfsharkserver;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;
import surfsharkserver.logger.Loger;

/**
 *
 * @author DEV-RAYS
 */
public class SurfSharkServer {

    public static ConnectionPool cp = null; 
    public static Loger logger;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
 // Open server socket for listening
            logger = new Loger();
            logger.init();
            Runtime runtime = Runtime.getRuntime();  
            long maxMemory = runtime.maxMemory();  
            long allocatedMemory = runtime.totalMemory();  
            long freeMemory = runtime.freeMemory();  
            console("free memory: " + freeMemory / 1024);  
            console("allocated memory: " + allocatedMemory / 1024);  
            console("max memory: " + maxMemory /1024);  
            console("total free memory: " +   
               (freeMemory + (maxMemory - allocatedMemory)) / 1024);         
         try    
        {   
            Class.forName("com.mysql.jdbc.Driver").newInstance();       
            console("Loaded com.mysql.jdbc.Driver......");   
        }   
        catch (ClassNotFoundException | InstantiationException | IllegalAccessException E)    
        {   
            console("Exception while loading driver");   
        }    
        try   
        {         
            console("Creating mysql connection...");   
             cp = new ConnectionPool();   
        }   
        catch(SQLException sqle)   
        { 
             System.exit(-1);
             console("Exception while loading driver"); 
        }   
        catch(Exception e)   
        {  
             System.exit(-1);
        }          
         
         
         
    ServerSocket serverSocket = null;
    int LISTENING_PORT = 8081;
    InetAddress addr = InetAddress.getByName("0.0.0.0");
    try 
    {
       serverSocket = new ServerSocket(LISTENING_PORT,0,addr);
       console("Server started on port " + LISTENING_PORT);
    }
    catch (IOException se) 
    {
       console("Can not start listening on port " + LISTENING_PORT);
       System.exit(-1);
    }

    // Start ServerDispatcher thread
    ServerDispatcher serverDispatcher = new ServerDispatcher();
    // Accept and handle client connections
    while (true) 
    {   
       try  
       {
           Socket socket = serverSocket.accept();
           ClientInfo clientInfo = new ClientInfo();
           clientInfo.mSocket = socket;
           if(!serverDispatcher.getClientByInet(socket.getInetAddress().toString()))
           {
            ClientListener clientListener = new ClientListener(clientInfo, serverDispatcher);
            ClientSender clientSender = new ClientSender(clientInfo, serverDispatcher);
            clientInfo.mClientListener = clientListener;
            clientInfo.mClientSender = clientSender;
            clientListener.start();
            clientSender.start();
            serverDispatcher.addClient(clientInfo);
           }else{
            ClientInfo clientInfox = serverDispatcher.getClientIdByInet(socket.getInetAddress().toString());
            clientInfox.mClientSender.interrupt();
            serverDispatcher.deleteClient(clientInfox);
            clientInfox.mSocket.close();
            console("Closing socket for:"+socket.getInetAddress().toString()+" alredy exists!");
            ClientListener clientListener = new ClientListener(clientInfo, serverDispatcher);
            ClientSender clientSender = new ClientSender(clientInfo, serverDispatcher);
            clientInfo.mClientListener = clientListener;
            clientInfo.mClientSender = clientSender;
            clientListener.start();
            clientSender.start();
            serverDispatcher.addClient(clientInfo);            
           }
       }
       catch (IOException ioe) 
       {
       }
        }
    }
    
    public static void console(String str) {
        try{
        SurfSharkServer.logger.loginfo(str);}catch(Exception e){}
    }
}
