/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package surfsharkserver.listeners;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import surfsharkserver.BaseSocket;
import surfsharkserver.ClientInfo;
import surfsharkserver.Encode;
import surfsharkserver.ServerDispatcher;
import surfsharkserver.SiteClass;
import surfsharkserver.SurfSharkServer;
import surfsharkserver.classes.DefaultResponse;
import surfsharkserver.classes.LoginInfo;
import surfsharkserver.cmd;

/**
 *
 * @author DEV-RAYS
 */
public class SitesModule {
        public static Map<Integer, String> getInstance(BaseSocket bs, ClientInfo mClientInfo, ServerDispatcher mServerDispatcher) {
        
            int cmdx = bs.cmd;
            switch(cmdx)
            {
                case cmd.cmd0:
                        try {
                            sendSites(bs, mClientInfo, mServerDispatcher);
                            
                        } catch (ClassNotFoundException ex) {
                            Logger.getLogger(SitesModule.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    break;     
                 case cmd.cmd1:
                        try {
                            saveSites(bs, mClientInfo, mServerDispatcher);
                            
                        } catch (ClassNotFoundException ex) {
                            Logger.getLogger(SitesModule.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    break;  
                  case cmd.cmd2:
                        try {
                            delSites(bs, mClientInfo, mServerDispatcher);
                            
                        } catch (ClassNotFoundException ex) {
                            Logger.getLogger(SitesModule.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    break;                    
            }
        return null;
    }
  private static void delSites(BaseSocket bs, ClientInfo clientInfo, ServerDispatcher mServerDispatcher) throws ClassNotFoundException
    {
        try {          
                  Connection conn = SurfSharkServer.cp.checkout();
                  String query = "";
                  String query2 = "";
                  ResultSet res;
                  Statement st;
                  query2 = "DELETE FROM `_surf_links` WHERE `id` =?";
                  PreparedStatement preparedStmtx = conn.prepareStatement(query2);
                  preparedStmtx.setLong(1, Long.parseLong(bs.value.toString()));
                  preparedStmtx.executeUpdate();
                  conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(SitesModule.class.getName()).log(Level.SEVERE, null, ex);
        }
    }   
  
 private static void saveSites(BaseSocket bs, ClientInfo clientInfo, ServerDispatcher mServerDispatcher) throws ClassNotFoundException
    {
        try {
                  Gson gson = new Gson();       
                  LoginInfo bsx = gson.fromJson(bs.value.toString().trim().replaceAll(" ",""), LoginInfo.class);
                  TypeToken<List<SiteClass>> token = new TypeToken<List<SiteClass>>(){};
                  List<SiteClass> personList = gson.fromJson(Encode.decrypt(bsx.password.toString()).trim().replaceAll(" ",""), token.getType());              
                  Connection conn = SurfSharkServer.cp.checkout();
                  String query = "";
                  String query2 = "";
                  ResultSet res;
                  Statement st;
                    for (int i = 0; i < personList.size(); i++) {                            
                            SiteClass site = personList.get(i);
                            query = "SELECT * FROM `_surf_links` WHERE id='"+site.id+"'";
                            st = conn.createStatement();
                            res = st.executeQuery(query);                           
                            if(res.next())
                            {
                                query2 = "UPDATE `_surf_links` SET `name` = ?, `region` = ?, `url` = ?, `refurl` = ?, `time`=?, `state` = ? WHERE  `id` =?";
                                PreparedStatement preparedStmt = conn.prepareStatement(query2);
                                preparedStmt.setString (1, site.name);
                                preparedStmt.setString (2, site.region);  
                                preparedStmt.setString (3, site.url);                                
                                preparedStmt.setString (4, site.refurl);
                                preparedStmt.setInt(5, site.time); 
                                preparedStmt.setInt(6, site.state); 
                                preparedStmt.setInt(7, site.id); 
                                preparedStmt.executeUpdate();
                                
                            }else{
                                query2 = "INSERT INTO `_surf_links` (`uid` ,`name` ,`region` ,`url` ,`refurl` ,`time` ,`state`) VALUES (?, ?, ?, ?, ?, ?, ?)";
                                PreparedStatement preparedStmt = conn.prepareStatement(query2);
                                preparedStmt.setString (1, site.name);
                                preparedStmt.setString (2, site.region);  
                                preparedStmt.setString (3, site.url);                                
                                preparedStmt.setString (4, site.refurl);
                                preparedStmt.setInt(5, site.time); 
                                preparedStmt.setInt(6, site.state); 
                                preparedStmt.setInt(7, site.id); 
                                preparedStmt.executeUpdate();                         
                                
                            
                            }
                            st.close();
                    }
                    conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(SitesModule.class.getName()).log(Level.SEVERE, null, ex);
        }
    }          
        
 private static void sendSites(BaseSocket bs, ClientInfo clientInfo, ServerDispatcher mServerDispatcher) throws ClassNotFoundException
    {
                  Gson gson = new Gson();
                  DefaultResponse dr = new DefaultResponse();
		  try {                  
		  Connection conn = SurfSharkServer.cp.checkout();
		  Statement st = conn.createStatement();
                  String query = "SELECT * FROM `_surf_links` WHERE uid='"+clientInfo.userID+"'";
                  ResultSet res = st.executeQuery(query);  
                  String jsonSTR = "[";
                    while(res.next())
                    {
                       int id = res.getInt("id");
                       int uid = res.getInt("uid");
                       String name = res.getString("name");
                       String url = res.getString("url");
                       String refurl = res.getString("refurl");
                       String time = res.getString("time");
                       String click = res.getString("click");
                       String state = res.getString("state");
                       String region = res.getString("region");
                       jsonSTR +="{\"id\":\""+id+"\", \"uid\":\""+uid+"\", \"name\":\""+name+"\", \"url\":\""+url+"\", \"refurl\":\""+refurl+"\", \"time\":\""+time+"\", \"click\":\""+click+"\", \"state\":\""+state+"\", \"region\":\""+region+"\"},";
                    }
                    jsonSTR = jsonSTR.substring(0,jsonSTR.length()-1);
                    jsonSTR +="]";
                    String encry = Encode.encrypt(jsonSTR);
                    conn.close();
                    dr.value = 1L;
                    dr.message = encry;
                    bs.value = gson.toJson(dr);
                    mServerDispatcher.sendMessage(clientInfo, gson.toJson(bs));                     		  
		  }
                  catch (Exception e) {
                   }      
    }       
        
        
        
}
