/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package surfsharkserver.listeners;

import com.google.gson.Gson;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import surfsharkserver.BaseSocket;
import surfsharkserver.Encode;
import surfsharkserver.SurfSharkServer;
import surfsharkserver.classes.LoginInfo;
import surfsharkserver.cmd;

/**
 *
 * @author DEV-RAYS
 */
public class ModuleLogin {

    public static Map<Integer, String> getInstance(BaseSocket bs) {
        
            int cmdx = bs.cmd;
            switch(cmdx)
            {
                case cmd.cmd0:
                    try {
                      return  login(bs);
                    } catch (ClassNotFoundException ex) {
                    }
                    break;    
                 case cmd.cmd2:
                    try {
                      return  register(bs);
                    } catch (ClassNotFoundException ex) {
                    }
                    break;                    
            }
        return null;
    }
    
    private static Map<Integer, String> login(BaseSocket bs) throws ClassNotFoundException
    {
                  Map<Integer, String> responese =  new HashMap<>();
                  Gson gson = new Gson();
                  LoginInfo bsx = gson.fromJson(bs.value.toString().trim().replaceAll(" ",""), LoginInfo.class);
                  String user = bsx.username;
                  String pass = Encode.encrypt(bsx.password);
		  try {                  
		  Connection conn = SurfSharkServer.cp.checkout();
		  Statement st = conn.createStatement();
                  String query = "SELECT * FROM _accounts WHERE userName=? AND passWord=?";                  
                  PreparedStatement preparedStmt = conn.prepareStatement(query);
                  preparedStmt.setString (1, user);
                  preparedStmt.setString (2, pass);
                  ResultSet res = preparedStmt.executeQuery();  
                  if(res.next()) {
                      int id = res.getInt("uid");
                      int time = res.getInt("time");
                      int type = res.getInt("type");
                      String userx = res.getString("userName");                  
                      responese.put(0, "true");
                      responese.put(1,  userx.substring(0, userx.indexOf("@")));
                      responese.put(2, ""+id);
                      responese.put(3, ""+time);
                      responese.put(4, ""+type);
                      responese.put(5, ""+bsx.hardwereKey);
                      responese.put(6, ""+bsx.country);
                      String loginSession = ""+id+System.currentTimeMillis();
                       Connection conn2 = SurfSharkServer.cp.checkout();
                       String queryx = "SELECT * FROM `_accounts` ORDER BY `_accounts`.`region` DESC";                  
                       PreparedStatement preparedStmtx = conn2.prepareStatement(queryx);
                       ResultSet resx = preparedStmtx.executeQuery();
                       String regionData = "";
                       while(resx.next())
                       {
                          String regionQ = resx.getString("region");
                          if(!regionData.contains(regionQ))
                          {
                             regionData += regionQ+",";
                          }  
                       }
                       conn2.close();
                       regionData = regionData.substring(0,regionData.length()-1);
                       responese.put(7, regionData);
                      String query3 = "UPDATE `_accounts` SET `lastLogin`=NOW(), `region`='"+bsx.country+"', loginSessionId='"+loginSession+"', hwid='"+bsx.hardwereKey+"' WHERE `uid`='"+id+"'";
                      st.executeUpdate(query3);  
                      try
                      {
                      Connection conn3 = SurfSharkServer.cp.checkout();
                      String query4 = "SELECT * FROM `_surf_views` WHERE `uid`='"+bsx.hardwereKey+"'";
                      PreparedStatement preparedStmtxy = conn3.prepareStatement(query4);
                      ResultSet resxy = preparedStmtxy.executeQuery();
                      if(resxy.next()) {
                        String regionQ = resxy.getString("viewed");
                        String[] asdx = regionQ.split("_");
                        responese.put(8, ""+asdx.length);
                      }else{
                        responese.put(8, "0"); 
                      }
                      
                      conn3.close();
                      }catch (Exception e)
                      {
                          System.out.println(e.toString());
                      }
                  } else {
                     responese.put(0, "false");
                     responese.put(1, "Wrong Password or Email!");           
                  }
		  conn.close();
		  } catch (Exception e) {
                        responese.put(0, "false");
                        responese.put(1, "Connection to mysql failed!");
                   }
           return responese;  
    }
    
     private static Map<Integer, String> register(BaseSocket bs) throws ClassNotFoundException
     {
                  Map<Integer, String> responese =  new HashMap<>();
                  Gson gson = new Gson();
                  LoginInfo bsx = gson.fromJson(bs.value.toString().trim().replaceAll(" ",""), LoginInfo.class);
                  String user = bsx.username;
                  String pass = Encode.encrypt(bsx.password);
		  try {                  
		  Connection conn = SurfSharkServer.cp.checkout();
                  String query = "INSERT INTO `_accounts` (`userName`, `passWord`) VALUES (?, ?)";                  
                  PreparedStatement preparedStmt = conn.prepareStatement(query);
                  preparedStmt.setString (1, user);
                  preparedStmt.setString (2, pass);
                  if(preparedStmt.executeUpdate() == 1)
                  {
                    Connection conn2 = SurfSharkServer.cp.checkout();
                    String queryx = "SELECT * FROM _accounts WHERE userName=? AND passWord=?";                  
                    PreparedStatement preparedStmtx = conn2.prepareStatement(queryx);
                    preparedStmtx.setString (1, user);
                    preparedStmtx.setString (2, pass);
                    ResultSet res = preparedStmtx.executeQuery();  
                    if(res.next())  
                    {
                        int id = res.getInt("uid");
                        int time = res.getInt("time");
                        int type = res.getInt("type");
                        String userx = res.getString("userName");
                        responese.put(0, "true");
                        responese.put(1,  userx.substring(0, userx.indexOf("@"))+ " account created!");
                        responese.put(2, ""+id);
                        responese.put(3, ""+time);
                        responese.put(4, ""+type);
                        responese.put(5, ""+bsx.hardwereKey);
                        responese.put(6, ""+bsx.country);
                         String loginSession = ""+id+System.currentTimeMillis();
                       Connection conn3 = SurfSharkServer.cp.checkout();
                       String queryxx = "SELECT * FROM `_accounts` ORDER BY `_accounts`.`region` DESC";                  
                       PreparedStatement preparedStmtxx = conn2.prepareStatement(queryxx);
                       ResultSet resx = preparedStmtxx.executeQuery();
                       String regionData = "";
                       while(resx.next())
                       {
                          String regionQ = resx.getString("region");
                          if(!regionData.contains(regionQ))
                          {
                             regionData += regionQ+",";
                          }  
                       }
                       conn2.close();
                       regionData = regionData.substring(0,regionData.length()-1);
                       responese.put(7, regionData);    
                      String query3 = "UPDATE `_accounts` SET `lastLogin`=NOW(), `region`='"+bsx.country+"', loginSessionId='"+loginSession+"', hwid='"+bsx.hardwereKey+"' WHERE `uid`='"+id+"'";
                      Statement st = conn.createStatement();
                      st.executeUpdate(query3);                        
                    }else{
                       responese.put(0, "false");
                       responese.put(1, "Wrong Password or Email!");
                    }
                    conn2.close();
                  }else{
                   responese.put(0, "false");   
                   responese.put(1, "Email already exists!");                 
                  }
		  conn.close();
		  } catch (Exception e) {
                        responese.put(0, "false");
                        responese.put(1, "Email already exists!");
                   }
                 return responese;
    }
}
