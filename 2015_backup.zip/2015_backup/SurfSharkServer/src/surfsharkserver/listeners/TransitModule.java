/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package surfsharkserver.listeners;

import com.google.gson.Gson;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.StringUtils;
import org.apache.commons.lang.ArrayUtils;
import surfsharkserver.BaseSocket;
import surfsharkserver.ClientInfo;
import surfsharkserver.Encode;
import surfsharkserver.IConfigs;
import surfsharkserver.SurfSharkServer;
import surfsharkserver.classes.DefaultResponse;

/**
 *
 * @author DEV-RAYS
 */
public class TransitModule {
    
     public static Map<Integer, String> getInstance(BaseSocket bs, ClientInfo clientInfo) throws IOException {
            int cmdx = bs.cmd;
            switch(cmdx) {
                case 1:
                    try {
                        try { 
                            giveCredit(bs, clientInfo);
                        } catch (SQLException ex) {
                            Logger.getLogger(TransitModule.class.getName()).log(Level.SEVERE, null, ex);
                        }
                      return checkLogin(clientInfo);
                    } catch (ClassNotFoundException ex) {
                        Logger.getLogger(ModuleLogin.class.getName()).log(Level.SEVERE, null, ex);
                    }
                break;                              
            }
        return null;
    }
    
    
    private static Map<Integer, String> checkLogin(ClientInfo clientInfo) throws ClassNotFoundException
    {
                  boolean foundsomthing = false;
                  clientInfo.viewed = null;
                  List<Long> clients = new ArrayList<>();
                  Map<Integer, String> responese =  new HashMap<>();
                  Gson gson = new Gson();
                  DefaultResponse dr = new DefaultResponse();
		  try {                  
		  Connection conn = SurfSharkServer.cp.checkout();
		  Statement st = conn.createStatement();
                  Statement st2 = conn.createStatement();
                  Statement st3 = conn.createStatement();
                  Statement stx = conn.createStatement();
                  String queryFirst = "SELECT * FROM `_accounts` WHERE time > 59";
                  String querySecond = "SELECT viewed FROM `_surf_views` WHERE uid='"+clientInfo.hwKey+"';";
                  Statement stxy = conn.createStatement();
                  Statement stxy_MYSA = conn.createStatement();
                  ResultSet resxy = stxy.executeQuery(querySecond);
                  String[] viewed = new String[]{"0"};    
                  if(resxy.next()) {     
                      viewed = resxy.getString("viewed").split("_");  
                      clientInfo.viewed = viewed;
                      clientInfo.surfed = viewed.length;
                  }
                  ResultSet resx = stx.executeQuery(queryFirst);
                  while(resx.next()) {
                      Long uid = resx.getLong("uid");  
                        clients.add(uid);                    
                  }
                    StringBuilder ret = new StringBuilder("");
                    for (int i = 0; viewed != null && i < viewed.length; i++) {
                        ret.append(viewed[i]);
                        if (i < viewed.length - 1) {
                            ret.append(',');
                        }
                    }
                    if(clients.contains(33L)) {
                        clients.remove(33L);
                    }
                    StringBuilder retx = new StringBuilder("");
                    for (int i = 0; clients != null && i < clients.size(); i++) {
                        retx.append(clients.get(i));
                        if (i < clients.size() - 1) {
                            retx.append(',');
                        }
                    }
                    String viewedBuild = ret.toString();
                    viewedBuild = viewedBuild.isEmpty() ? "0":viewedBuild;
                    String clientsWithCredt = retx.toString();
                    clientsWithCredt = clientsWithCredt.isEmpty() ? "0":clientsWithCredt; 
                    String query = "SELECT * FROM `_surf_links` WHERE id NOT IN ("+viewedBuild+") AND uid NOT IN (33) AND state=1 AND uid IN ("+clientsWithCredt+") ORDER BY `time` DESC";
                    ResultSet res = st.executeQuery(query);
                    DefaultResponse dr_prefered = null;
                    boolean hasNew = false;
                    while(res.next()) {
                       Long id = res.getLong("id");
                       Long uid = res.getLong("uid");    
                       String url = res.getString("url");
                       String refurl = res.getString("refurl");
                       String preF_refurl = res.getString("region");
                       int time = res.getInt("time");
                       if(uid != clientInfo.userID) {
                          if(!clientInfo.region.equals(preF_refurl) && !hasNew) {
                             dr_prefered = new DefaultResponse();
                             dr_prefered.value = id;
                             dr_prefered.link = url;
                             dr_prefered.referelink = refurl;
                             dr_prefered.seconds = time;
                             dr_prefered.surfed = clientInfo.surfed;  
                             dr_prefered.minutes = clientInfo.thisSesion;
                             hasNew = true;
                          }else{
                              if(clientInfo.region.equals(preF_refurl)) {
                                    dr.value = id;
                                    dr.link = url;
                                    dr.referelink = refurl;
                                    dr.seconds = time;
                                    dr.surfed = clientInfo.surfed;  
                                    dr.minutes = clientInfo.thisSesion;                                  
                                    String query2 = "UPDATE `_surf_links` SET `click`=click+1 WHERE  `id` =?";
                                    PreparedStatement preparedStmt = conn.prepareStatement(query2);
                                    preparedStmt.setLong(1, id); 
                                    preparedStmt.executeUpdate();
                                    responese.put(0, "true");
                                    responese.put(1,  gson.toJson(dr));    
                                    foundsomthing = true;
                                    dr_prefered = null;
                                    String loginSession = ""+id+System.currentTimeMillis();
                                    String query14445 = "UPDATE `_accounts` SET `lastLogin`=NOW(), loginSessionId='"+loginSession+"' WHERE `uid`='"+clientInfo.userID+"'";
                                    st3.executeUpdate(query14445);
                                    hasNew = false;
                                    break;
                              }
                          }
                       }
                    }
                    if(hasNew)
                    {
                        String query2 = "UPDATE `_surf_links` SET `click`=click+1 WHERE  `id` =?";
                        PreparedStatement preparedStmt = conn.prepareStatement(query2);
                        preparedStmt.setLong(1, dr_prefered.value); 
                        preparedStmt.executeUpdate();
                        responese.put(0, "true");
                        responese.put(1,  gson.toJson(dr_prefered));    
                        foundsomthing = true;
                        String loginSession = ""+dr_prefered.value+System.currentTimeMillis();
                        String query14445 = "UPDATE `_accounts` SET `lastLogin`=NOW(), loginSessionId='"+loginSession+"' WHERE `uid`='"+clientInfo.userID+"'";
                        st3.executeUpdate(query14445);
                    }
                    if(!foundsomthing) {
                    String query_MYS = "SELECT * FROM `_surf_links` WHERE id NOT IN ("+viewedBuild+") AND state=1 ORDER BY `time` DESC";
                    ResultSet res_MYS = stxy_MYSA.executeQuery(query_MYS);
                        while(res_MYS.next()) {
                           Long id = res_MYS.getLong("id");
                           Long uid = res_MYS.getLong("uid");                     
                            if(uid != clientInfo.userID) {
                             String query2 = "UPDATE `_surf_links` SET `click`=click+1 WHERE  `id` =?";
                              PreparedStatement preparedStmt = conn.prepareStatement(query2);
                              preparedStmt.setLong(1, id); 
                              preparedStmt.executeUpdate();
                              String url = res_MYS.getString("url");
                              String refurl = res_MYS.getString("refurl");
                              int time = res_MYS.getInt("time");
                              dr.value = id;
                              dr.link = url;
                              dr.referelink = refurl;
                              dr.seconds = time;
                              dr.surfed = clientInfo.surfed;  
                              dr.minutes = clientInfo.thisSesion;
                              responese.put(0, "true");
                              responese.put(1,  gson.toJson(dr));  
                              foundsomthing = true;
                                String loginSession = ""+id+System.currentTimeMillis();
                                String query14444 = "UPDATE `_accounts` SET `lastLogin`=NOW(), loginSessionId='"+loginSession+"' WHERE `uid`='"+clientInfo.userID+"'";
                                st2.executeUpdate(query14444);                                  
                              break;
                           } 
                        }                
                    }      
                    if(!foundsomthing) {
                    String url = "";
                    int time = 0;
                    dr.value = 0L;
                    dr.link = "http://www.games-shark.com/nomoresites.php";
                    dr.referelink = "";
                    dr.seconds = 60;
                    dr.surfed = clientInfo.surfed;
                    responese.put(0, "true");
                    responese.put(1,  gson.toJson(dr));    
                    }
		  conn.close();
		  } catch (Exception e) {
                        responese.put(1, "false");
                        responese.put(0, "Connection Faild!");
                   }
                 return responese;
        
    }
    
    private static void giveCredit(BaseSocket bs, ClientInfo clientInfo) throws SQLException, IOException
    { 
        if(bs != null)
        {
             Gson gson = new Gson();
            String encoded = Encode.decrypt(StringUtils.newStringUtf8(Base64.decodeBase64(bs.value.toString().trim())));
            DefaultResponse bsx = gson.fromJson(encoded.trim().replaceAll(" ",""), DefaultResponse.class);   
            String[] viewed = new String[]{"0"};
            if(bsx != null)
            {            
                Long lastsiteID = bsx.value;
                Long userID = clientInfo.userID;
                int time = bsx.seconds;
                int credit = 0;
                int type = 0;
                if(lastsiteID > 0)
                {
		  Connection conn = SurfSharkServer.cp.checkout();
                  String queryx = "UPDATE _accounts SET time=? WHERE uid=?";                  
                  PreparedStatement preparedStmtx = conn.prepareStatement(queryx);  
                  String queryxx = "UPDATE _accounts SET time=time-? WHERE uid=? AND time >= ?";                  
                  PreparedStatement preparedStmtxx = conn.prepareStatement(queryxx);                   
                  String query = "SELECT uid,time,type FROM `_accounts` WHERE uid=?";
                  PreparedStatement preparedStmt = conn.prepareStatement(query);
                  preparedStmt.setLong(1, userID);
                  ResultSet res = preparedStmt.executeQuery();
                  Statement st = conn.createStatement();
                  Statement stx = conn.createStatement();
                  if(res.next())
                  {
                    String querySecond = "SELECT viewed FROM `_surf_views` WHERE uid='"+clientInfo.hwKey+"';";
                    Statement stxy = conn.createStatement();
                    ResultSet resxy = stxy.executeQuery(querySecond);                     
                    if(resxy.next())
                    {     
                        viewed = resxy.getString("viewed").split("_");  
                        clientInfo.viewed = viewed;
                    }                      
                    String[] second = new String[1];
                    second[0] = lastsiteID.toString();
                    String[] both = (String[]) ArrayUtils.addAll(clientInfo.viewed, second);                      
                    StringBuilder ret = new StringBuilder("");
                        for (int i = 0; both != null && i < both.length; i++) {
                            ret.append(both[i]);
                            if (i < both.length - 1) {
                                ret.append('_');
                            }
                        }
                     String idsxzczc = ret.toString();
                     String query3 = "INSERT INTO _surf_views (uid, viewed) VALUES('"+clientInfo.hwKey+"','"+idsxzczc+"') ON DUPLICATE KEY UPDATE viewed=VALUES(viewed)";
                     stx.executeUpdate(query3); 
                     clientInfo.viewed = both;
                     clientInfo.surfed = clientInfo.viewed.length;
                     credit = res.getInt("time");
                     type = res.getInt("type");
                    int devider = 70;
                    if(type == 0)
                    {
                      devider = IConfigs.percentage0;  
                    }else{    
                      devider = IConfigs.percentage1;      
                    }
                    //70 / 100 * 31
                    float percentx = (devider / 100.0f) * time;
                    int percentage = (int)Math.round(percentx);
                    int calculate = (int)credit + percentage;
                    credit = calculate;
                    int at = 10;
                    int surfed = clientInfo.surfed; // 23
                    int result = 0;
                    if (surfed > 0)
                    {
                        if(surfed > at) // 23
                        {
                            int surfedx = surfed / at; // 2
                            int surfedy = at * surfedx; //10 * 2 = 20
                            result = surfed - surfedy; // 23 - 20 = 3
                        }
                        else
                        {
                            result = surfed;
                        }
                        
                    }
                    int bonus = 0;
                    if(result == 0 || result == 10)
                    {
                        double bonux = clientInfo.surfed * 0.02;
                        bonus = 10 + (int)bonux;
                        credit = credit + bonus;
                    }
                    clientInfo.thisSesion = clientInfo.thisSesion + percentage;                    
                    SurfSharkServer.logger.loginfo("- UID:"+clientInfo.userID+" Surfed:"+clientInfo.surfed+" Bonus:"+bonus+" Time:"+time+" Seconds Earned:"+percentage+ " having %:"+devider+" Total seconds:"+calculate);
                    //get credits
                    preparedStmtx.setInt(1, credit);
                    preparedStmtx.setLong(2, userID);
                    preparedStmtx.executeUpdate();
                        String queryxxy = "SELECT uid,id FROM `_surf_links` WHERE id='"+lastsiteID+"';";
                        ResultSet reso = st.executeQuery(queryxxy);
                        if(reso.next())
                        {
                            Long lastsiteUID = reso.getLong("uid");
                            preparedStmtxx.setInt(1, time);
                            preparedStmtxx.setLong(2, lastsiteUID);
                            preparedStmtxx.setInt(3, time);
                            preparedStmtxx.executeUpdate();
                        }
                  }
                  preparedStmtx.close();
                  preparedStmt.close();
                  conn.close();               
                  clientInfo.minutes = credit;
                  clientInfo.type = type;
                }
            }
        }   
    }  
     
}
