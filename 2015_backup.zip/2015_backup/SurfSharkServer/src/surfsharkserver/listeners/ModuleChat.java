/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package surfsharkserver.listeners;

import com.google.gson.Gson;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import surfsharkserver.BaseSocket;
import surfsharkserver.ClientInfo;
import surfsharkserver.Encode;
import surfsharkserver.ServerDispatcher;
import surfsharkserver.SurfSharkServer;
import surfsharkserver.classes.ChatResponse;
import surfsharkserver.classes.DefaultResponse;
import surfsharkserver.cmd;

/**
 *
 * @author DEV-RAYS
 */
public class ModuleChat {
      public static Map<Integer, String> getInstance(BaseSocket bs, ClientInfo clientInfo, ServerDispatcher mServerDispatcher) throws SQLException {
        
            int cmdx = bs.cmd;
            switch(cmdx)
            {
                case cmd.cmd0:
                      return  sendChat(bs, clientInfo, mServerDispatcher);   
                 case cmd.cmd1:
                      return  reciveChat(bs);    
                 case cmd.cmd2:
                      return  getAllChat(bs, clientInfo, mServerDispatcher); 
            }
        return null;
    }  

    private static Map<Integer, String> sendChat(BaseSocket bs, ClientInfo clientInfo, ServerDispatcher mServerDispatcher) throws SQLException {
         Map<Integer, String> responese =  new HashMap<>();

         Gson gson = new Gson();
         ChatResponse cr = gson.fromJson(bs.value.toString().trim().replaceAll(" ",""), ChatResponse.class);
         Connection conn = SurfSharkServer.cp.checkout();
         String query = "INSERT INTO `sharkgames`.`chat_messages` (`UserName` ,`Posted` ,`Message`) VALUES (?, CURRENT_TIMESTAMP , ?)";
         PreparedStatement preparedStmt = conn.prepareStatement(query);
         preparedStmt.setString (1, clientInfo.UserName);
         String msgx = "";
        try {
            msgx = URLEncoder.encode(cr.Message, "UTF-8").replace(" ", "+");
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(ModuleChat.class.getName()).log(Level.SEVERE, null, ex);
        }
         preparedStmt.setString (2, msgx);
         if(!msgx.isEmpty())
         {
         preparedStmt.executeUpdate();
         }
         
         conn.close();
         
        responese.put(0, "true");
        DefaultResponse dr = new DefaultResponse();
        Connection conn2 = SurfSharkServer.cp.checkout();
        String queryx = "SELECT * FROM `chat_messages` ORDER BY `chat_messages`.`MessageID` DESC";                  
        PreparedStatement preparedStmtx = conn2.prepareStatement(queryx);
        ResultSet res = preparedStmtx.executeQuery();
        String jsonSTR = "[";
        int countingMsgx = 0;
        while(res.next())
        {
            
           int MessageID = res.getInt("MessageID");
           String UserName = res.getString("UserName");
           String Posted = res.getString("Posted");
           String Message = res.getString("Message");
           if(!Message.isEmpty() && Message.length() > 0)
           {
           jsonSTR +="{\"MessageID\":\""+MessageID+"\", \"UserName\":\""+UserName+"\", \"Posted\":\""+Posted+"\", \"Message\":\""+Message+"\"},";
           }
            countingMsgx++;
        }
         if(countingMsgx > 50)
        {
            Connection conn3 = SurfSharkServer.cp.checkout();
            Statement st2 = conn3.createStatement();
            String query14444 = "TRUNCATE TABLE chat_messages";
            st2.executeUpdate(query14444); 
            conn3.close();    
        }       
         jsonSTR = jsonSTR.substring(0,jsonSTR.length()-1);
         jsonSTR +="]";
         String encry = Encode.encrypt(jsonSTR);
         dr.value = 1L;
         dr.message = encry;
         bs.value = gson.toJson(dr);
         conn2.close();
         bs.cmd = 0;
         mServerDispatcher.sendMessageToAllClients(clientInfo, gson.toJson(bs));
         responese.put(0, "true");
         return responese;
    }


    private static Map<Integer, String> reciveChat(BaseSocket bs) {
         Map<Integer, String> responese =  new HashMap<>();
         responese.put(0, "true");
         System.out.println("reciveChat");
         return responese;
    }

    private static Map<Integer, String> getAllChat(BaseSocket bs, ClientInfo clientInfo, ServerDispatcher mServerDispatcher) throws SQLException {
        Map<Integer, String> responese =  new HashMap<>();
        responese.put(0, "true");
        DefaultResponse dr = new DefaultResponse();
        Gson gson = new Gson();
        Connection conn2 = SurfSharkServer.cp.checkout();
        String queryx = "SELECT * FROM `chat_messages` ORDER BY `chat_messages`.`MessageID` DESC";                  
        PreparedStatement preparedStmtx = conn2.prepareStatement(queryx);
        ResultSet res = preparedStmtx.executeQuery();
        String jsonSTR = "[";
        int countingMsgx = 0;
        while(res.next())
        {
           int MessageID = res.getInt("MessageID");
           String UserName = res.getString("UserName");
           String Posted = res.getString("Posted");
           String Message = res.getString("Message");
           if(!Message.isEmpty() && Message.length() > 0)
           {
           jsonSTR +="{\"MessageID\":\""+MessageID+"\", \"UserName\":\""+UserName+"\", \"Posted\":\""+Posted+"\", \"Message\":\""+Message+"\"},";
           }
           countingMsgx++;
        }
        if(countingMsgx > 50)
        {
            Connection conn3 = SurfSharkServer.cp.checkout();
            Statement st2 = conn3.createStatement();
            String query14444 = "TRUNCATE TABLE chat_messages";
            st2.executeUpdate(query14444); 
            conn3.close();             
        }
        jsonSTR = jsonSTR.substring(0,jsonSTR.length()-1);
        jsonSTR +="]";
        String encry = Encode.encrypt(jsonSTR);
        dr.value = 1L;
        dr.message = encry;
        bs.value = gson.toJson(dr);
        bs.cmd = 3;
        conn2.close();
        mServerDispatcher.sendMessage(clientInfo, gson.toJson(bs));
        return responese;
    }
}
