/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package surfsharkserver;

/**
 *
 * @author DEV-RAYS
 */
    import java.util.*;

    public class ServerDispatcher 
        {
        private Vector mMessageQueue = new Vector();
        private Vector<ClientInfo> mClients = new Vector<ClientInfo>();


    public synchronized void addClient(ClientInfo aClientInfo) {
        mClients.add(aClientInfo);
    }

    public synchronized void deleteClient(ClientInfo aClientInfo) {
        int clientIndex = mClients.indexOf(aClientInfo);
        if (clientIndex != -1) {
            mClients.removeElementAt(clientIndex);
        }
    }


    public void sendMessage(ClientInfo aClientInfo, String aMessage) {
        aClientInfo.mClientSender.sendMessage(Encode.encrypt(aMessage));

    }
    
    public synchronized int getClientCount() {
        return mClients.size();
    }
    
    public synchronized ClientInfo getClientById(int index) {
        for (int i = 0; i < mClients.size(); i++) {
            ClientInfo infy = (ClientInfo) mClients.get(i);
            Long uid = infy.userID;
            if(uid == index)
            {
                return infy;
                
            }
          } 
        return null;
    }
    public synchronized boolean getClientByInet(String index) {
        
        for (int i = 0; i < mClients.size(); i++) {
            ClientInfo infy = (ClientInfo) mClients.get(i);
            String InetIp = infy.InetIp;
            if(InetIp == null ? index == null : InetIp.equals(index))
            {
                return true;
                
            }
          } 
        return false;
    }
    public synchronized ClientInfo getClientIdByInet(String index) {
        
        for (int i = 0; i < mClients.size(); i++) {
            ClientInfo infy = (ClientInfo) mClients.get(i);
            String InetIp = infy.InetIp;
            if(InetIp == null ? index == null : InetIp.equals(index))
            {
                return infy;
                
            }
          } 
        return null;
    }    

    public void sendMessageToAllClients(ClientInfo clientInfo, String aMessage) {
        try{
        for (int i = 0; i < mClients.size(); i++) {
            ClientInfo infy = (ClientInfo) mClients.get(i);
            infy.mClientSender.sendMessage(Encode.encrypt(aMessage));
          } 
        }catch(Exception e){}
    }
}
