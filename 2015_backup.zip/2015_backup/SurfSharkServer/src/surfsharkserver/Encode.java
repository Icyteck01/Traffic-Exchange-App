/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package surfsharkserver;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.codec.binary.Base64;

/**
 *
 * @author DEV-RAYS
 */
public class Encode {
    
    private String iv = "1234567890123456";
    private String key = "gamessharkkeyidx";    
       
public static String md5(String input) throws NoSuchAlgorithmException {
    MessageDigest md = MessageDigest.getInstance("MD5");
    byte[] messageDigest = md.digest(input.getBytes());
    BigInteger number = new BigInteger(1, messageDigest);
    return number.toString(16);
}

private String decryptfu(String encryptedData) {
    String decryptedData = null;
    try {
        SecretKeySpec keyspec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");
        IvParameterSpec ivspec = new IvParameterSpec(iv.getBytes("UTF-8"));
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, keyspec, ivspec);
        byte[] encryptedByteArray = Base64.decodeBase64(encryptedData.trim().getBytes());
        byte[] decryptedByteArray = cipher.doFinal(encryptedByteArray);
        decryptedData = new String(decryptedByteArray, "UTF8");
    } catch (UnsupportedEncodingException | NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException e) {
        SurfSharkServer.console(e.toString());
    }
    return decryptedData;
}

private String encryptfu(String encryptedData) {
    String decryptedData = null;
    try {
        SecretKeySpec keyspec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");
        IvParameterSpec ivspec = new IvParameterSpec(iv.getBytes("UTF-8"));
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, keyspec, ivspec);
        byte[] encryptedByteArray = encryptedData.trim().getBytes();
        byte[] decryptedByteArray = cipher.doFinal(encryptedByteArray);
        decryptedData = new String(Base64.encodeBase64(decryptedByteArray), "UTF8");
    } catch (UnsupportedEncodingException | NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException e) {
        SurfSharkServer.console(e.toString());
    }
    return decryptedData;
}

    public static String encrypt(String input){
        return new Encode().encryptfu(input);
    }

    public static String decrypt(String input){
        return new Encode().decryptfu(input);
    }

}
