/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package surfsharkserver;

/**
 *
 * @author DEV-RAYS
 */
public class Module {
    public static final int LOGIN = 0;
    public static final int TRANSIT = 1;
    public static final int SITES = 2;
    public static final int CHAT = 3;
}
