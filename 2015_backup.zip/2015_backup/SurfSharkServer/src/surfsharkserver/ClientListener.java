package surfsharkserver;

import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.StringUtils;
import surfsharkserver.classes.DefaultResponse;
import surfsharkserver.listeners.ModuleChat;
import surfsharkserver.listeners.ModuleLogin;
import surfsharkserver.listeners.SitesModule;
import surfsharkserver.listeners.TransitModule;


public class ClientListener extends Thread {
    private ServerDispatcher mServerDispatcher;
    private ClientInfo mClientInfo;
    private BufferedReader mIn;
    private String message;
    private String decoded = null;

    public ClientListener(ClientInfo aClientInfo,
        ServerDispatcher aServerDispatcher) throws IOException {
        mClientInfo = aClientInfo;
        mServerDispatcher = aServerDispatcher;
        Socket socket = aClientInfo.mSocket;
        mIn = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        mClientInfo.InetIp = socket.getInetAddress().toString();
        IConfigs.totalOnline = mServerDispatcher.getClientCount();
        SurfSharkServer.logger.loginfo("- Init new client connection from:"+mClientInfo.InetIp+" Total Online:"+IConfigs.totalOnline);
    }

    /**
     * Until interrupted, reads messages from the client socket, forwards them
     * to the server dispatcher and notifies the server dispatcher.
     */
    @Override
    public void run() {
        message = "";
        Date date = new Date();
        while (!isInterrupted()) {
            try {
                message = mIn.readLine();
                if (message == null) {
                    break;
                }             
                    decoded = StringUtils.newStringUtf8(Base64.decodeBase64(message));
                    String decodedx = Encode.decrypt(decoded);
                    Gson gson = new Gson();
                    BaseSocket bs = gson.fromJson(decodedx.trim().replaceAll(" ",""), BaseSocket.class);
                    int module = bs.module;
                    Map<Integer, String> map =  new HashMap<Integer, String>();
                    switch(module)
                    {
                        case Module.LOGIN:
                            map = ModuleLogin.getInstance(bs);
                                if(map != null)
                                {
                                    DefaultResponse dr = new DefaultResponse();
                                    if("true".equals(map.get(0)))
                                    {
                                        mClientInfo.userID = Long.parseLong(map.get(2));
                                        dr.uid = mClientInfo.userID;
                                        dr.value = 1L;
                                        dr.message = map.get(1);
                                        dr.minutes = Integer.parseInt(map.get(3));
                                        dr.type = Integer.parseInt(map.get(4));
                                        dr.regions = map.get(7);
                                        dr.surfed = Integer.parseInt(map.get(8));
                                        mClientInfo.type = Integer.parseInt(map.get(4));
                                        mClientInfo.minutes = Integer.parseInt(map.get(3));
                                        bs.value = gson.toJson(dr);
                                        mClientInfo.hwKey = map.get(5);
                                        if(bs.cmd == 2)
                                        {
                                            bs.module = -1;
                                        }
                                        if(!IConfigs.clients.containsKey(mClientInfo.hwKey))
                                        {
                                            mServerDispatcher.sendMessage(mClientInfo, gson.toJson(bs));
                                            IConfigs.clients.put(mClientInfo.hwKey, new ArrayList<Long>());
                                            mClientInfo.UserName = map.get(1);
                                            mClientInfo.region = map.get(6);
                                            SurfSharkServer.logger.loginfo("LOGIN-Module: "+  map.get(1)+" HDKEY:"+ map.get(5)+" REGION:"+ map.get(6) +" Total Online:"+IConfigs.clients.size());
                                        }else{
                                            SurfSharkServer.logger.loginfo("LOGIN-Module-FAILL: "+  map.get(1));
                                            dr.value = 0L;
                                            dr.uid = mClientInfo.userID;
                                            dr.message = "You can't open more then one client on the same computer!";
                                            bs.value = gson.toJson(dr);
                                            mServerDispatcher.sendMessage(mClientInfo, gson.toJson(bs));                                         
                                        }
                                    }else{
                                        SurfSharkServer.logger.loginfo("LOGIN-Module-FAILL: "+  map.get(1));
                                        dr.value = 0L;
                                        dr.uid = mClientInfo.userID;
                                        dr.message = map.get(1);
                                        bs.value = gson.toJson(dr);
                                        mServerDispatcher.sendMessage(mClientInfo, gson.toJson(bs));
                                    }
                                }                       
                            break;
                        case Module.TRANSIT:
                             map = TransitModule.getInstance(bs, mClientInfo);
                              DefaultResponse dr = new DefaultResponse();
                                    if("true".equals(map.get(0)))
                                    {
                                        dr.uid = mClientInfo.userID;
                                        dr.value = 1L;
                                        dr.message = map.get(1);
                                        dr.minutes = mClientInfo.minutes;
                                        dr.type = mClientInfo.type;
                                        bs.value = gson.toJson(dr);
                                        mServerDispatcher.sendMessage(mClientInfo, gson.toJson(bs));
                                    }
                            break;   
                         case Module.SITES:
                             SitesModule.getInstance(bs, mClientInfo, mServerDispatcher);
                            break;
                         case Module.CHAT:
                             map = null;
                            try {
                                map = ModuleChat.getInstance(bs, mClientInfo, mServerDispatcher);
                            } catch (SQLException ex) {
                                Logger.getLogger(ClientListener.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            if(map!= null && "true".equals(map.get(0)))
                            {


                            } 
                             break;
                    }                   
            } 
            catch (IOException e) {
                break;
            }

        }
        try {
            SurfSharkServer.logger.loginfo("Client disconetcs from the server having UserID:"+this.mClientInfo.userID+" HWID:"+this.mClientInfo.hwKey+" IP:"+mClientInfo.InetIp+" Total Online:"+IConfigs.clients.size());
        } catch (IOException ex) {
            Logger.getLogger(ClientListener.class.getName()).log(Level.SEVERE, null, ex);
        }
        if(IConfigs.clients.containsKey(mClientInfo.hwKey))
           {
               IConfigs.clients.remove(mClientInfo.hwKey);
           }         
        // Communication is broken. Interrupt both listener and sender threads
        mClientInfo.mClientSender.interrupt();
        mServerDispatcher.deleteClient(mClientInfo);    
    }

}