﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SurfShark.program
{
    class Module
    {
        public static int LOGIN = 0;
        public static int TRANSIT = 1;
        public static int SITES = 2;

    }
}
