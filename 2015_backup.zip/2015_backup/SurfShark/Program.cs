﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using SurfShark.program;
using SurfShark;


namespace WindowsFormsApplication1
{
    public class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        /// 
        private static NotifyIcon icon;
        public static NotifyIcon Notifier { get { return icon; } }
        public static Boolean isdebug = false;

        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            try
            {
                Forms.login = new LoginDialog();
                Forms.main = new CoreSystem();
                Forms.surf = new MainProgram();
                Forms.util = new UrlUtilityForm();
                Forms.chat = new ChatWindow();

                icon = new NotifyIcon();
                
                icon.Icon = System.Drawing.Icon.ExtractAssociatedIcon(Application.ExecutablePath);
                icon.ContextMenu = new ContextMenu(new MenuItem[] {
                new MenuItem("Show", (s, e) => {
                    Forms.main.WindowState = FormWindowState.Normal;                  
                }),
                new MenuItem("Exit", (s, e) => {
                    icon.Visible = false;
                    icon.Dispose();
                    Application.Exit();Environment.Exit(0);
                }),
                    
                });
                icon.DoubleClick += new EventHandler(notifyIcon1_DoubleClick);
                icon.Visible = true;

                icon.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info; //Shows the info icon so the user doesn't thing there is an error.
                icon.BalloonTipText = "Hello, I am your friendly neighborhood traffic Shark. If you need me just double click this icon.";
                icon.BalloonTipTitle = "Games-Sharks.com's Traffic Tool.";
                icon.Text = "Games-Sharks.com's Traffic Tool.";
                icon.ShowBalloonTip(500);
                icon.Visible = true;
                if (args.Length > 0 || isdebug)
                {
                    Application.Run();
                }
                else
                {
                    icon.Visible = false;
                    icon.Dispose();
                    Application.Exit();
                    Environment.Exit(0);                      
                }
                icon.Visible = false;
            }
            catch (Exception)
            {
                icon.Visible = false;
                icon.Dispose();
                Application.Exit();
                Environment.Exit(0);
            }
        }
        private static void notifyIcon1_DoubleClick(object Sender, EventArgs e)
        {
            CoreSystem.resize_window();
        }
        public static void disposeIcon()
        {
            try
            {
                Program.Notifier.Visible = false;
                Program.Notifier.Dispose();
            }
            catch (Exception) {}

        }

    }
}
