﻿using SurfShark.programs;
using System;
using System.Collections.Generic;
using System.Text;

namespace SurfShark.program
{
    class ProgramVars
    {
        public static String stat = "Disconected";
        public static int minutes = 0;
        public static String surfed = "0";
        public static String user = "0";
        public static int ratioTxt = 70;
        public static int type = 0;
        public static String typeTxt = "";
        public static List<SiteClass> siteClasses = new List<SiteClass>();
        public static String[] regions = null;
        public static List<ChatResponse> chatList = new List<ChatResponse>();
    }
}
