﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SurfShark.programs
{
    [Serializable]
    public class Hostip
    {
        public string country_name;
        public string country_code;
        public string city;
        public string ip;
    }
}
