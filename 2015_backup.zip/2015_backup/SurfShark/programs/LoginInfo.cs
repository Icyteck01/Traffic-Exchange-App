﻿using System;
using System.Collections.Generic;

using System.Text;

namespace SurfShark.program
{
    class LoginInfo
    {
        public String username = "";
        public String password = "";
        public String hardwereKey = "";
        public String country = "";
    }
}
