﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SurfShark.programs
{
    [Serializable]
    public class ChatResponse
    {
        public int MessageID = 0;
        public String UserName = "";
        public String Posted = "";
        public String Message = "";
    }
}
