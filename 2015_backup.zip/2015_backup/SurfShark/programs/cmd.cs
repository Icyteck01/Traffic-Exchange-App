﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SurfShark.program
{
    class cmd
    {
        public static int cmd0 = 0;
        public static int cmd1 = 1;
        public static int cmd2 = 2;
    }
}
