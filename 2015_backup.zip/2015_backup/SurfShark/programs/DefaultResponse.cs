﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SurfShark.program
{
    class DefaultResponse
    {
        public int value = 0;
        public String message = "";
        public int minutes = 0;
        public int surfed = 0;
        public String link = "";
        public String referelink = "";
        public int seconds = 10;
        public int type = 0;
        public int uid = 0;
        public String region = "International";
        public String regions = null;
    }
}
