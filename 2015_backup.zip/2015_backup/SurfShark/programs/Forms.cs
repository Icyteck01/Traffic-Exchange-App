﻿using System;
using System.Collections.Generic;
using System.Text;
using WindowsFormsApplication1;
using System.IO;
using SurfShark.program;
using Newtonsoft.Json;
using System.Windows.Forms;
using Microsoft.Win32;
using SurfShark.programs;
using System.Net;
using Newtonsoft.Json.Linq;

namespace SurfShark
{
    class Forms
    {
       // public static CoreSystem main;
       // public static LoginDialog login;
       // public static MainProgram surf;
       // public static UrlUtilityForm util;

        public static CoreSystem main { get; set; }
        public static LoginDialog login { get; set; }
        public static MainProgram surf { get; set; }
        public static UrlUtilityForm util { get; set; }
        public static Boolean is_connected_to_server { get; set; }

        public static ChatWindow chat { get; set; }

        private static string hwKey { get; set; }
        private static Boolean finished = false;
        private static Boolean regionGot = false;
        private static string region { get; set; }

        internal static string GetInfo()
        {
            try {
                WebClient wc = new WebClient();
                String dw = wc.DownloadString("http://api.hostip.info/get_json.php");
                Hostip li = (Hostip)JsonConvert.DeserializeObject<Hostip>(dw);
                region = li.country_name;
                return region;
            }
            catch (Exception) { return ""; }
        }

        internal static string getRegion()
        {
            if (regionGot && region.Length > 0)
            {
                return region;
            }
            else
            {

                regionGot = true;
                return GetInfo();
            }
            
        }

        internal static string getHwKey()
        {
           // if(finished && hwKey.Length > 2)
           // {
           //     return hwKey;
           // }
            return FPkey.Value();
        }


        internal static void saveLastLogin(String username, String password)
        {
            String hardwereKey = "";
            try
            {
                RegistryKey key = Registry.CurrentUser.OpenSubKey("Software\\Games Shark Limited\\Values", true);
                if (key != null)
                {
                    string value = key.GetValue("hash").ToString();
                    LoginInfo li = (LoginInfo)JsonConvert.DeserializeObject<LoginInfo>(Encrypt.Decode(value));
                    string usernamex = li.username;
                    if (!usernamex.Equals(username))
                    {
                        hardwereKey = FPkey.Value();
                        String loginInfo = "{\"username\":\"" + username + "\",\"password\":\"" + password + "\",\"hardwereKey\":\"" + hardwereKey + "\",\"country\":\"" + getRegion() + "\"}";
                        string valuex = Encrypt.Encode(loginInfo);
                        key.SetValue("hash", valuex);
                        key.Close();
                    }
                    else
                    {
                        hardwereKey = li.hardwereKey;
                        key.Close();
                    }
                }
                else
                {
                    hardwereKey = FPkey.Value();
                    String loginInfo = "{\"username\":\"" + username + "\",\"password\":\"" + password + "\",\"hardwereKey\":\"" + hardwereKey + "\",\"country\":\"" + getRegion() + "\"}";
                    string value = Encrypt.Encode(loginInfo);
                    key = Microsoft.Win32.Registry.CurrentUser.CreateSubKey("Software\\Games Shark Limited\\Values");
                    key.SetValue("hash", value);
                    key.Close();
                }
            }
            catch (Exception)
            {
            }
            hwKey = hardwereKey;
            finished = true;
        }


        internal static LoginInfo getLastLogin()
        {
            try
            {
                RegistryKey key = Registry.CurrentUser.OpenSubKey("Software\\Games Shark Limited\\Values", true);
                if (key != null)
                {
                    string value = key.GetValue("hash").ToString();
                    LoginInfo li = (LoginInfo)JsonConvert.DeserializeObject<LoginInfo>(Encrypt.Decode(value));
                    key.Close();
                    hwKey = li.hardwereKey;
                    region = getRegion();
                    finished = true;
                    return li;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
