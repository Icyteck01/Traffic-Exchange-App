﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;
using SurfShark;
using System.Runtime.Serialization.Formatters.Binary;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SurfShark.program;
using System.Text.RegularExpressions;

namespace WindowsFormsApplication1
{
    public partial class MainProgram : Form
    {
        public static MainProgram CoreSystemInstance;
        private System.Windows.Forms.Timer timer1;
        internal static int counter = 0;
        internal static int counterMax = 0;
        internal static int Minutes = 0;
        internal static int reward = 0;
        internal static Boolean loaded = false;
        internal static int tempCounter = 0;
        public bool ShowPercentage { get; private set; }

        public MainProgram()
        {
            LoginDialog.CheckForIllegalCrossThreadCalls = false;
            CoreSystemInstance = this;
            this.timer1 = new System.Windows.Forms.Timer();
            this.timer1.Tick += new EventHandler(this.timer1_Tick);
            this.timer1.Enabled = false;
            this.timer1.Stop();
            InitializeComponent();
            this.webBrowser1.NewWindow += new CancelEventHandler(webBrowser1_NewWindow);
            this.webBrowser1.DocumentCompleted += new WebBrowserDocumentCompletedEventHandler(webBrowser1_navi);
            this.webBrowser1.IsWebBrowserContextMenuEnabled = false;
            ((Control)this.webBrowser1).Enabled = false;
        }

        private void webBrowser1_navi(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            //MessageBox.Show("Compleated!");
            Application.DoEvents();
            MainProgram.loaded = true;
        }

        private void webBrowser1_NewWindow(object sender, CancelEventArgs e)
        {
            e.Cancel = true;
            Application.DoEvents();
        }

        public String getAlexa(String URL)
        {
            
            String AlexaRank = "N/A";
            try
            {
                WebRequest request = WebRequest.Create("http://data.alexa.com/data?cli=10&dat=snbamz&url=" + URL);
                WebResponse response = request.GetResponse();
                StreamReader sr = new StreamReader(response.GetResponseStream());
                string line = "";
                while ((line = sr.ReadLine()) != null)
                {
                    Regex rankRegex = new Regex("<REACH RANK=\"(.*)\"/>");
                    Match match = rankRegex.Match(line);
                    if (match.Success)
                    {
                        AlexaRank = match.Groups[1].Value.ToString();
                    }
                }
                sr.Close();
            }
            catch (Exception) { }
            return AlexaRank;
        }

        public void navigate_to(String url)
        {

            this.EndInvoke(this.BeginInvoke((Action)(() =>
            {
                this.label8.Text = getAlexa(url).ToString();
                this.webBrowser1.Stop();
                this.webBrowser1.DocumentText =
                    "<html></body><center><h1>Loading next site....</h1></center></body></html>";
                this.webBrowser1.Navigate(url);
                this.startTick();
                float newMins = (ProgramVars.ratioTxt / 100.0f) * reward;
                this.rewardTxt.Text = "" + (int)(Math.Round(newMins))+" Seconds.";
                this.surfedTotalTxt.Text = "" + (int.Parse(ProgramVars.surfed));
                this.memberTypeTxt.Text = ProgramVars.typeTxt;
                this.RatioText.Text = ProgramVars.ratioTxt+"%";
                Application.DoEvents();
                //100 / 
                try {
                    int at = 10;
                    int surfed = int.Parse(ProgramVars.surfed); // 23
                    int result = 0;
                    if (surfed > 0)
                    {
                        if(surfed > at) // 23
                        {
                            int surfedx = surfed / at; // 2
                            int surfedy = at * surfedx; //10 * 2 = 20
                            result = surfed - surfedy; // 23 - 20 = 3
                        }
                        else
                        {
                            result = surfed;
                        }
                        
                    }

                    int percent = result * (100 / at);
                    progressBar1.Value = percent;
                }
                catch(Exception e) { MessageBox.Show(e.ToString()); }
                this.minsNowTxt.Text = Minutes /60 + " Minute" + ((Minutes / 60) > 0 ? "s" : "");
                int tsx = ProgramVars.minutes /60;
                this.TotalMinutesTxt.Text = tsx +" Minute"+(tsx > 0?"s":"");
            }))
            );
        }

        private void startTick()
        {
            if (CoreSystem.startedToSurf)
            {
                this.timer1.Enabled = true;
                this.timer1.Interval = 1000; // 1 second
                this.timer1.Start();
                MainProgram.loaded = false;
                MainProgram.tempCounter = 10;
                changePergentage();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (MainProgram.loaded || MainProgram.tempCounter <= 0)
            {
                MainProgram.counter--;
                if (MainProgram.counter <= 0)
                {

                    this.webBrowser1.DocumentText =
                        "<html></body><center><h1>Loading next site....</h1></center></body></html>";
                    this.timer1.Stop();
                }
                else
                {
                    if (!CoreSystem.startedToSurf)
                    {
                        this.timer1.Stop();
                    }
                }
            }
            else
            {
                MainProgram.tempCounter--;
            }
            changePergentage();
        }

        private void changePergentage()
        {
            try
            {
                int raza = 100 / MainProgram.counterMax;
                progressBar2.Value = raza * MainProgram.counter;
            }
            catch (Exception) { }
        }
        protected void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            if (CoreSystem.startedToSurf)
            {
                if (CloseCancel() == true)
                {
                    CoreSystem.resize_window();
                    CoreSystem.startedToSurf = false;
                    e.Cancel = true;
                    this.Hide();
                }
                else
                {
                    e.Cancel = true;

                }
            }

        }

        public static bool CloseCancel()
        {
            const string message = "Are you sure that you would like to exit Surf Shark?";
            const string caption = "Question:";
            var result = MessageBox.Show(message, caption,
                                         MessageBoxButtons.YesNo,
                                         MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
                return true;
            else
                return false;
        }

        private void webBrowser1_NewWindow_1(object sender, CancelEventArgs e)
        {

        }

        private void webBrowser1_ControlAdded(object sender, ControlEventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You get "+( 10 + int.Parse(ProgramVars.surfed) * 0.02)+" seconds when this status is full!");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure to open in a new window this site ?",
                                                 "Open in new window",
                                                 MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                // If 'Yes', do something here.
                Preview pv = new Preview();
                pv.Show();
                pv.navigate_to(webBrowser1.Url.ToString());
            }

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure to report this site as spam ?",
                                                 "Report as Spam!",
                                                 MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                // If 'Yes', do something here.
                MessageBox.Show("Thank you we will investigate your request asap!");
            }
        }
    }
}
