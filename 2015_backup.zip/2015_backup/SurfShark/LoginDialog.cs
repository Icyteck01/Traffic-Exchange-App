﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;
using SurfShark.program;
using WindowsFormsApplication1;
using System.Diagnostics;
using System.Text.RegularExpressions;

namespace SurfShark
{
    public partial class LoginDialog : Form
    {
        public static LoginDialog LoginDialogInstance;      
        public LoginDialog()
        {
            LoginDialogInstance = this;
            InitializeComponent();
            LoginDialog.CheckForIllegalCrossThreadCalls = false;
            LoginInfo li = Forms.getLastLogin();
            if (li != null)
            {
                autologin(li);
            }
            notice.Text = "";

        }

        private void autologin(LoginInfo li)
        {
            if (li != null)
            {
                textBox1.Text = li.username;
                textBox2.Text = li.password;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            this.textBox1.Text = "";
           // MessageBox.Show(""+IsValidEmail(this.textBox1.Text));
        }
        private String cleanStr(String strToCheck)
        {
            String newx;
            string[] allowed = new string[] { "=", ".", "-", "_", ",", " ", "[", "]", ":", "+", "|", "!", "%", "&", "@", "/", "*", "?", "#", "'" };
            for (int i = 0; i < allowed.Length; i++)
            {
               strToCheck = strToCheck.Replace(allowed[i].ToString(), "");
            }
            newx = strToCheck;
            return newx;
        }

        private Boolean isAllowed(String strToCheck)
        {
            
            Regex rg = new Regex(@"^[a-zA-Z0-9]*$");
            return rg.IsMatch(cleanStr(strToCheck));
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            String username = textBox1.Text;
            String password = textBox2.Text;
            LoginDialog.username = username;
            LoginDialog.password = password;
            if (!IsValidEmail(username))
            {
                MessageBox.Show("Incorrect Input for Username!\nMust contain a valid email address format.");
                return;
            }
            if (username.Length < 4 || username.Length > 30)
            {
                MessageBox.Show("Incorrect Length for Username!\nMust be bettween 30 and 4 characters");
                return;
            }
            if (password.Length < 4 || password.Length > 20)
            {
                MessageBox.Show("Incorrect Length for Password!\nMust be bettween 20 and 4 characters");
                return;
            }
            if (!isAllowed(username))
            {
                MessageBox.Show("Incorrect Input for Username!\nAllowed characters are: A-Z 0-9 [ ] : - + | ! , . % & @ / * _ ? # \'");
                return;
            }
            if (!isAllowed(password))
            {
                MessageBox.Show("Incorrect Input for Password!\nAllowed characters are: A-Z 0-9 [ ] : - + | ! , . % & @ / * _ ? # \'");
                return;
            }
            notice.Text = "Please wait...";
            String loginInfo = "{\"username\":\"" + username + "\",\"password\":\"" + password + "\",\"hardwereKey\":\"" + Forms.getHwKey() + "\",\"country\":\"" + Forms.getRegion() + "\"}";

            if (Forms.is_connected_to_server)
            {
             CoreSystem.main.NetSend(loginInfo, Module.LOGIN, cmd.cmd0);         
            }
            notice.Text = "";
        }


        private void textBox2_Click(object sender, EventArgs e)
        {
            this.textBox2.Text = "";
        }


        private void Form1_Closing(object sender, FormClosingEventArgs e)
        {
            if (!Forms.is_connected_to_server || !CoreSystem.LoggedIn)
            {
                Program.disposeIcon();
                Application.Exit();
                Environment.Exit(0);
            }

        }

        private void LoginDialog_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (!Forms.is_connected_to_server || !CoreSystem.LoggedIn)
            {
                Program.disposeIcon();
                Application.Exit();
                Environment.Exit(0);
            }
        }

        private void buttonRegister_Click(object sender, EventArgs e)
        {
            String username = textBox4.Text;
            String password = textBox3.Text;
            String repassword = textBox5.Text;

            if (!IsValidEmail(username))
            {
                MessageBox.Show("Incorrect Input for Username!\nMust contain a valid email address format.");
                return;
            }
            if (username.Length < 4 || username.Length > 30)
            {
                MessageBox.Show("Incorrect Length for Username!\nMust be bettween 30 and 4 characters");
                return;
            }
            if (password.Length < 4 || password.Length > 20)
            {
                MessageBox.Show("Incorrect Length for Password!\nMust be bettween 20 and 4 characters");
                return;
            }
            if (repassword.Length < 4 || repassword.Length > 20)
            {
                MessageBox.Show("Incorrect Length for RE-Password!\nMust be bettween 20 and 4 characters");
                return;
            }
            if (!isAllowed(username))
            {
                MessageBox.Show("Incorrect Input for Username!\nAllowed characters are: A-Z 0-9 [ ] : - + | ! , . % & @ / * _ ? # \'");
                return;
            }
            if (!isAllowed(password))
            {
                MessageBox.Show("Incorrect Input for Password!\nAllowed characters are: A-Z 0-9 [ ] : - + | ! , . % & @ / * _ ? # \'");
                return;
            }
            if (!isAllowed(repassword))
            {
                MessageBox.Show("Incorrect Input for RE-Password!\nAllowed characters are: A-Z 0-9 [ ] : - + | ! , . % & @ / * _ ? # \'");
                return;
            }
            if (password != repassword)
            {
                MessageBox.Show("Password and RE-Password must be the same!");
                return;

            }
            String loginInfo = "{\"username\":\"" + username + "\",\"password\":\"" + password + "\",\"hardwereKey\":\"" + Forms.getHwKey() + "\",\"country\":\"" + Forms.getRegion() + "\"}";
            CoreSystem.main.NetSend(loginInfo, Module.LOGIN, cmd.cmd2);
        }


        public static string username { get; set; }

        public static string password { get; set; }
    }
}
