﻿namespace SurfShark
{
    partial class CoreSystem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CoreSystem));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.MemberTypExd = new System.Windows.Forms.Label();
            this.User = new System.Windows.Forms.Label();
            this.Minutes = new System.Windows.Forms.Label();
            this.Surfed = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Statustct = new System.Windows.Forms.Label();
            this.myurls = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.buymins = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(109, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 17);
            this.label1.TabIndex = 5;
            this.label1.Text = "Membership Type:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(102, 1);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 24);
            this.label2.TabIndex = 5;
            this.label2.Text = "Welcome";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(109, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Minutes:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(109, 77);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(133, 17);
            this.label4.TabIndex = 5;
            this.label4.Text = "Sites Surfed Today:";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button1.Location = new System.Drawing.Point(11, 117);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(149, 36);
            this.button1.TabIndex = 7;
            this.button1.Text = "Surf Shark";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // MemberTypExd
            // 
            this.MemberTypExd.AutoSize = true;
            this.MemberTypExd.BackColor = System.Drawing.Color.Transparent;
            this.MemberTypExd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.MemberTypExd.ForeColor = System.Drawing.Color.White;
            this.MemberTypExd.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.MemberTypExd.Location = new System.Drawing.Point(257, 44);
            this.MemberTypExd.MinimumSize = new System.Drawing.Size(67, 13);
            this.MemberTypExd.Name = "MemberTypExd";
            this.MemberTypExd.Size = new System.Drawing.Size(71, 13);
            this.MemberTypExd.TabIndex = 5;
            this.MemberTypExd.Text = "Normal Shark";
            this.MemberTypExd.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // User
            // 
            this.User.AutoSize = true;
            this.User.BackColor = System.Drawing.Color.Transparent;
            this.User.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.User.ForeColor = System.Drawing.Color.White;
            this.User.Location = new System.Drawing.Point(189, 5);
            this.User.MaximumSize = new System.Drawing.Size(131, 17);
            this.User.MinimumSize = new System.Drawing.Size(131, 17);
            this.User.Name = "User";
            this.User.Size = new System.Drawing.Size(131, 17);
            this.User.TabIndex = 5;
            this.User.Text = "Guest";
            this.User.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Minutes
            // 
            this.Minutes.AutoSize = true;
            this.Minutes.BackColor = System.Drawing.Color.Transparent;
            this.Minutes.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.Minutes.ForeColor = System.Drawing.Color.White;
            this.Minutes.Location = new System.Drawing.Point(228, 64);
            this.Minutes.MaximumSize = new System.Drawing.Size(100, 13);
            this.Minutes.MinimumSize = new System.Drawing.Size(100, 13);
            this.Minutes.Name = "Minutes";
            this.Minutes.Size = new System.Drawing.Size(100, 13);
            this.Minutes.TabIndex = 5;
            this.Minutes.Text = "0";
            this.Minutes.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // Surfed
            // 
            this.Surfed.AutoSize = true;
            this.Surfed.BackColor = System.Drawing.Color.Transparent;
            this.Surfed.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.Surfed.ForeColor = System.Drawing.Color.White;
            this.Surfed.Location = new System.Drawing.Point(273, 81);
            this.Surfed.MaximumSize = new System.Drawing.Size(55, 13);
            this.Surfed.MinimumSize = new System.Drawing.Size(55, 13);
            this.Surfed.Name = "Surfed";
            this.Surfed.Size = new System.Drawing.Size(55, 13);
            this.Surfed.TabIndex = 5;
            this.Surfed.Text = "0";
            this.Surfed.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(108, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 17);
            this.label5.TabIndex = 5;
            this.label5.Text = "Status:";
            // 
            // Statustct
            // 
            this.Statustct.AutoSize = true;
            this.Statustct.BackColor = System.Drawing.Color.Transparent;
            this.Statustct.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.Statustct.ForeColor = System.Drawing.Color.White;
            this.Statustct.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Statustct.Location = new System.Drawing.Point(261, 24);
            this.Statustct.MaximumSize = new System.Drawing.Size(67, 13);
            this.Statustct.MinimumSize = new System.Drawing.Size(67, 13);
            this.Statustct.Name = "Statustct";
            this.Statustct.Size = new System.Drawing.Size(67, 13);
            this.Statustct.TabIndex = 5;
            this.Statustct.Text = "Disconected";
            this.Statustct.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // myurls
            // 
            this.myurls.BackColor = System.Drawing.Color.LawnGreen;
            this.myurls.Cursor = System.Windows.Forms.Cursors.Hand;
            this.myurls.FlatAppearance.BorderSize = 0;
            this.myurls.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.myurls.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.myurls.ForeColor = System.Drawing.Color.Black;
            this.myurls.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.myurls.Location = new System.Drawing.Point(169, 117);
            this.myurls.Name = "myurls";
            this.myurls.Size = new System.Drawing.Size(151, 36);
            this.myurls.TabIndex = 7;
            this.myurls.Text = "My Websites";
            this.myurls.UseVisualStyleBackColor = false;
            this.myurls.Click += new System.EventHandler(this.myurls_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Red;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button3.Location = new System.Drawing.Point(169, 159);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(151, 36);
            this.button3.TabIndex = 7;
            this.button3.Text = "Exit";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.OnFormClosingx);
            // 
            // buymins
            // 
            this.buymins.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(113)))), ((int)(((byte)(5)))));
            this.buymins.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buymins.FlatAppearance.BorderSize = 0;
            this.buymins.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buymins.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buymins.ForeColor = System.Drawing.Color.White;
            this.buymins.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.buymins.Location = new System.Drawing.Point(9, 159);
            this.buymins.Name = "buymins";
            this.buymins.Size = new System.Drawing.Size(151, 36);
            this.buymins.TabIndex = 7;
            this.buymins.Text = "Buy Minutes";
            this.buymins.UseVisualStyleBackColor = false;
            this.buymins.Click += new System.EventHandler(this.buymins_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::SurfShark.Properties.Resources.user_default_avatar;
            this.pictureBox2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox2.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.InitialImage")));
            this.pictureBox2.Location = new System.Drawing.Point(2, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(101, 101);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.RoyalBlue;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(14, 82);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 8;
            this.button2.Text = "View Chat";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // CoreSystem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(167)))), ((int)(((byte)(239)))));
            this.ClientSize = new System.Drawing.Size(332, 214);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.buymins);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.myurls);
            this.Controls.Add(this.Statustct);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Surfed);
            this.Controls.Add(this.Minutes);
            this.Controls.Add(this.User);
            this.Controls.Add(this.MemberTypExd);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(348, 253);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(348, 253);
            this.Name = "CoreSystem";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Surfing Shark - Core System";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnFormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label User;
        public System.Windows.Forms.Label Minutes;
        public System.Windows.Forms.Label Surfed;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.Label Statustct;
        public System.Windows.Forms.Label MemberTypExd;
        private System.Windows.Forms.Button myurls;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button buymins;
        private System.Windows.Forms.Button button2;
    }
}