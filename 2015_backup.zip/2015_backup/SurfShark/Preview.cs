﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SurfShark
{
    public partial class Preview : Form
    {
        public Preview()
        {
            InitializeComponent();
        }

        public void navigate_to(String url)
        {

            this.EndInvoke(this.BeginInvoke((Action)(() =>
            {
                textBox1.Text = url;
                this.webBrowser1.Navigate(url);
            }))
            );
        }


    }
}
