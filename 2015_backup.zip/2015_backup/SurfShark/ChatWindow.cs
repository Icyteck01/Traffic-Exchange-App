﻿using Newtonsoft.Json;
using SurfShark.program;
using SurfShark.programs;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace SurfShark
{
    public partial class ChatWindow : Form
    {
        public ChatWindow()
        {
            InitializeComponent();
        }
        private String lastMSg = "";
        internal void loadAll()
        {
            checkBox1.Checked = CoreSystem.chatEnabled;
            ProgramVars.chatList.Reverse();
            chatTextBox.Text = "";
            var sb = new StringBuilder();
            sb.Append(@"{\rtf1\ansi");
            foreach (ChatResponse chat in ProgramVars.chatList)
            {
                String msg = chat.Message;
                String UserName = chat.UserName;
                if (msg.Length > 0 && msg != String.Empty)
                {
                    if(IsNumeric(UserName))
                    {
                        UserName = "Guest";
                    }
                    sb.Append(string.Format(@"\b {0}: \b0 ", UserName).ToString());
                    sb.Append(Uri.UnescapeDataString(msg).Replace('+', ' '));
                    sb.Append(@" \line ");
                }
            }
            sb.Append(@"}");
            chatTextBox.Rtf = sb.ToString();
            chatTextBox.SelectionStart = chatTextBox.Text.Length;
            chatTextBox.ScrollToCaret();
        }
        public static bool IsNumeric(object Expression)
        {
            double retNum;

            bool isNum = Double.TryParse(Convert.ToString(Expression), System.Globalization.NumberStyles.Any, System.Globalization.NumberFormatInfo.InvariantInfo, out retNum);
            return isNum;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (CoreSystem.canSendChat)
            {
                string msg = textBox2.Text;
                string msgx = Regex.Replace(msg, @"\s+", "");
                string xczxc = @"[^a-zA-Z0-9 :;,_!\?@()#$%\^&\*-+= < > ]";
                string xczxcx = @"^[a-zA-Z0-9 :;,_!\?@()#$%\^&\*-+= < > ]+$";
                if (msgx.Length > 0)
                {
                    if(msgx.Length > 40)
                    {
                        MessageBox.Show("Too many characters! Max 20!");
                        return;
                    }
                    if (lastMSg.Equals(msg))
                    {
                        MessageBox.Show("You already said that!");
                        return;
                    }
                    if (!System.Text.RegularExpressions.Regex.IsMatch(msg, xczxcx))
                    {

                        Regex rgxp = new Regex(xczxc);
                        textBox2.Text = rgxp.Replace(msg, "");
                        MessageBox.Show("InvalidCharacters");
                        return;
                    }

                    lastMSg = msg;
                    ChatResponse cr = new ChatResponse();
                    cr.Message = textBox2.Text;
                    var sz = JsonConvert.SerializeObject(cr).ToString();
                    CoreSystem.main.NetSend(sz, Module.CHAT, cmd.cmd0);
                    CoreSystem.canSendChat = false;
                    textBox2.Text = "";
                }
                else
                {
                    MessageBox.Show("Please write somthing!");
                }
            }
        }

        private void ChatWindow_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (CoreSystem.startedToSurf)
            {
                CoreSystem.resize_window();
            }
            this.Hide();
            CoreSystem.chatLoaded = false;
        }

        private void textBox2_KeyDown(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                if (CoreSystem.canSendChat)
                {
                    string msg = textBox2.Text;
                    string msgx = Regex.Replace(msg, @"\s+", "");
                    string xczxc = @"[^a-zA-Z0-9 :;,_!\?@()#$%\^&\*-+= < > ]";
                    string xczxcx = @"^[a-zA-Z0-9 :;,_!\?@()#$%\^&\*-+= < > ]+$";
                    if (msgx.Length > 0)
                    {
                        if (msgx.Length > 40)
                        {
                            MessageBox.Show("Too many characters! Max 20!");
                            return;
                        }
                        if (lastMSg.Equals(msg))
                        {
                            MessageBox.Show("You already said that!");
                            return;
                        }
                        if (!System.Text.RegularExpressions.Regex.IsMatch(msg, xczxcx))
                        {

                            Regex rgxp = new Regex(xczxc);
                            textBox2.Text = rgxp.Replace(msg, "");
                            MessageBox.Show("InvalidCharacters");
                            return;
                        }
                        lastMSg = msg;
                        ChatResponse cr = new ChatResponse();
                        cr.Message = textBox2.Text;
                        var sz = JsonConvert.SerializeObject(cr).ToString();
                        CoreSystem.main.NetSend(sz, Module.CHAT, cmd.cmd0);
                        CoreSystem.canSendChat = false;
                        textBox2.Text = "";
                    }
                    else
                    {
                        MessageBox.Show("Please write somthing!");
                    }
                }
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            CoreSystem.chatEnabled = checkBox1.Checked;
        }
    }
}
