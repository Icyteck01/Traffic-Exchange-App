﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Net.Sockets;
using System.Threading;
using System.Net;
using SurfShark.program;
using Newtonsoft.Json;
using WindowsFormsApplication1;
using System.Timers;
using Newtonsoft.Json.Linq;
using SurfShark.programs;

namespace SurfShark
{
    public partial class CoreSystem : Form
    {

        private StreamWriter swSender;
        private StreamReader srReceiver;
        private TcpClient tcpServer;
        private Thread thrMessaging;
        public IPAddress ipAddr;
        private String serverIpx = "autosurf-traffic-exchange.com";

        private int serverPort = 8081;
        public static Boolean LoggedIn = false;
        public static Boolean hasPass = false;
        public static CoreSystem main;
        public static Boolean startedToSurf = false;
        private System.Timers.Timer aTimer;
        private int oldSiteId = 0;
        private int oldSeconds = 0;
        public static int userID = 0;
        public static Boolean isUtilOpen = false;
        public static Boolean chatLoaded = false;
        public static Boolean canSendChat = true;
        public static Boolean chatEnabled = true;
        public CoreSystem()
        {
            main = this;
            InitializeComponent();
            if (!Forms.is_connected_to_server)
            {
                this.InCon();
            }
            if (!CoreSystem.LoggedIn)
            {
                    Forms.login.Show();
            }

            Statustct.Text = ProgramVars.stat;
            this.Minutes.Text = ProgramVars.minutes / 60 + " ";
            Surfed.Text = ProgramVars.surfed;
            User.Text = ProgramVars.user;
            LoginDialog.CheckForIllegalCrossThreadCalls = false;
            this.aTimer = new System.Timers.Timer();
            this.aTimer.Elapsed += new ElapsedEventHandler(this.OnTimedEvent);
            this.aTimer.Enabled = false;
            this.aTimer.Stop();
        }

        static byte[] GetBytes(string str)
        {
            byte[] bytes = new byte[str.Length * sizeof(char)];
            System.Buffer.BlockCopy(str.Trim().ToCharArray(), 0, bytes, 0, bytes.Length);
            return bytes;
        }

        private void InitializeConnection()
        {

            
            if(Program.isdebug)
            {
                this.ipAddr = IPAddress.Parse("86.122.52.0");
            }
            else
            {
                IPHostEntry Host = Dns.GetHostEntry(serverIpx);
                this.ipAddr = IPAddress.Parse(Host.AddressList[0].ToString());
            }
            this.tcpServer = new TcpClient();
            tcpServer.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.KeepAlive, true);
            try
            {
                this.tcpServer.Connect(this.ipAddr, this.serverPort);
                this.swSender = new StreamWriter(this.tcpServer.GetStream());
                this.thrMessaging = new Thread(new ThreadStart(ReceiveMessages));
                this.thrMessaging.Start();
                Forms.is_connected_to_server = true;
            }
            catch (Exception e)
            {
                MessageBox.Show("Unable to connect to the server!\nPlease try again later.");
                this.dealwithDC(e);
            }
        }
        private void ReceiveMessages()
        {
            while (true)
            {
                try
                {
                    srReceiver = new StreamReader(tcpServer.GetStream());
                    String data = srReceiver.ReadLine().ToString().Trim();    
                    if (data != null && data.Length > 0)
                    {
                        
                        baseSocket tmp = PacketClient.decodeBS(data);
                        this.processMessage(tmp);
                    }
                }
                catch (Exception e)
                {
                    this.dealwithDC(e);
                }
            }
        }

        private void SendMessage(String message, int module, int cmd)
        {
            if (Forms.is_connected_to_server)
            {
                baseSocket bs = new baseSocket();
                String timeStamp = (DateTime.Now.ToUniversalTime() - new DateTime(1970, 1, 1)).TotalSeconds.ToString();
                bs.module = module;
                bs.cmd = cmd;
                bs.value = message;
                bs.time = timeStamp;
                var sz = Encrypt.Encode(JsonConvert.SerializeObject(bs).ToString());
                var plainTextBytes = GetBytes(sz);
                String encoded = System.Convert.ToBase64String(plainTextBytes);
                swSender.WriteLine(encoded);
                swSender.Flush();
            }

        }

        public void NetSend(String message, int module, int cmd)
        {
            this.SendMessage(message, module, cmd);

        }
        private void InCon()
        {
            this.InitializeConnection() ;

        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            CoreSystem.resize_window();
        }

        private String askFOrnewSite(int type, int oldValueId)
        {
            DefaultResponse dr = new DefaultResponse();
            dr.type = type;
            dr.value = oldValueId;
            dr.seconds = oldSeconds;
            dr.region = Forms.getRegion();
            var sz = Encrypt.Encode(JsonConvert.SerializeObject(dr).ToString());
            var plainTextBytes = GetBytes(sz);
            String encoded = System.Convert.ToBase64String(plainTextBytes);
            return encoded;
        }

        private void CTimedEvent(int time, String url)
        {
            this.aTimer.Stop();
            if (startedToSurf)
            {
                time = time + 1;
                int totalTIme =1000 * time;
                this.aTimer.Interval = totalTIme;
                this.aTimer.Enabled = true;              
                Forms.surf.navigate_to(url);
            }
        }

        private void OnTimedEvent(object source, ElapsedEventArgs e)
        {
            this.SendMessage(askFOrnewSite(1, this.oldSiteId), Module.TRANSIT, cmd.cmd1);         
        }

        internal static void resize_window()
        {
            
            if (Forms.main.WindowState == FormWindowState.Minimized)
            {
                if (!Forms.is_connected_to_server)
                {
                    if (Forms.login.IsDisposed)
                    {
                        Forms.login = new LoginDialog();
                    }
                    Forms.login.Show();
                }
                else
                {
                    Forms.main.WindowState = FormWindowState.Normal;
                    Forms.main.ShowInTaskbar = true;
                }
                
            }
            else
            {
                Forms.main.WindowState = FormWindowState.Minimized;
                Forms.main.ShowInTaskbar = false;
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!startedToSurf)
            {
                if (!Forms.surf.IsDisposed)
                {
                    Forms.surf.Show();
                }
                else
                {
                    Forms.surf = new MainProgram();
                    Forms.surf.Show();
                }
                CoreSystem.resize_window();
                startedToSurf = true;
                CTimedEvent(10, "http://www.autosurf-traffic-exchange.com");
                this.SendMessage(askFOrnewSite(0,0), Module.TRANSIT, cmd.cmd1);
            }
        }


        protected void OnFormClosingx(object sender, EventArgs e)
        {
            if (CloseCancel() == true)
            {
                Program.disposeIcon();
                Application.Exit();
                Environment.Exit(0);
            }
            else
            {
                CoreSystem.resize_window();
            }

        }

        public static bool CloseCancel()
        {
            const string message = "Would you like to exit or minimize Surf Shark?\nPress Yes to exit and No to Minimize";
            const string caption = "Question:";
            var result = MessageBox.Show(message, caption,
                                         MessageBoxButtons.YesNo,
                                         MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
                return true;
            else
                return false;
        }


        private void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            CoreSystem.resize_window();
        }

        private void dealwithDC(Exception e)
        {
            Forms.is_connected_to_server = false;
            if (this.tcpServer != null)
            {
                this.tcpServer.Close();
            }
            MessageBox.Show("You have been disconnected from server!\nProgram will now exit!");
            Program.disposeIcon();
            Environment.Exit(0);
            Application.Exit();
        }


        private void processMessage(baseSocket bs)
        {
            int module = bs.module;
            int cmd = bs.cmd;
            String value = bs.value.ToString().Trim(); // can be json
            switch (module)
            {
                case 0: //Recived login
                    DefaultResponse dr = null;
                    if (value != null && value.Length > 0)
                    {
                        dr = JsonConvert.DeserializeObject<DefaultResponse>(value);
                    }
                    if (dr != null)
                    {
                        if (dr.value == 1)
                        {
                            Statustct.Text = "Connected";
                            this.Minutes.Text = dr.minutes / 60 + " ";
                            Surfed.Text = "" + dr.surfed;
                            User.Text = "" + dr.message;
                            ProgramVars.stat = "Connected";
                            ProgramVars.surfed = "" + dr.surfed;
                            ProgramVars.user = "" + dr.message;
                            ProgramVars.minutes = dr.minutes;
                            ProgramVars.type = dr.type;
                            ProgramVars.regions = dr.regions.Split(',');
                            CoreSystem.userID = dr.uid;
                            ProgramVars.ratioTxt = ProgramVars.type == 0 ? 70 : 100;
                            ProgramVars.typeTxt = ProgramVars.type == 0 ? "Normal Shark" : "Super Shark";
                            MemberTypExd.Text = ProgramVars.typeTxt;
                            CoreSystem.LoggedIn = true;
                            Forms.login.Invoke(new MethodInvoker(delegate ()
                            {
                                Forms.main.Show();
                                Forms.login.Close();
                            }));
                            Forms.saveLastLogin(LoginDialog.username, LoginDialog.password);
                        }
                        else
                        {
                            CoreSystem.LoggedIn = false;
                            MessageBox.Show(dr.message);
                        }
                    }

                    break;

                case 1: //Recived packet from server
                    DefaultResponse drx = JsonConvert.DeserializeObject<DefaultResponse>(value);
                    if (drx != null)
                    {
                        if (drx.value == 1)
                        {
                            DefaultResponse dry = JsonConvert.DeserializeObject<DefaultResponse>(drx.message.ToString());
                            MainProgram.counter = dry.seconds;
                            MainProgram.counterMax = dry.seconds;
                            MainProgram.Minutes = dry.minutes;
                            MainProgram.reward = dry.seconds;
                            CTimedEvent(dry.seconds, dry.link);
                            this.Minutes.Text = MainProgram.Minutes / 60 + " ";;
                            Surfed.Text = "" + dry.surfed;
                            oldSiteId = dry.value;
                            oldSeconds = dry.seconds;
                            ProgramVars.stat = "Connected";
                            ProgramVars.minutes = drx.minutes;
                            ProgramVars.surfed = "" + dry.surfed;
                            ProgramVars.type = drx.type;
                            ProgramVars.ratioTxt = ProgramVars.type == 0 ? 70 : 100;
                            ProgramVars.typeTxt = ProgramVars.type == 0 ? "Normal Shark" : "Super Shark";
                            MemberTypExd.Text = ProgramVars.typeTxt;
                        }

                    }
                    break;
                case 2: //Loaded URLS
                    DefaultResponse drexe = JsonConvert.DeserializeObject<DefaultResponse>(value);
                    if (drexe != null)
                    {
                        if (drexe.value == 1)
                        {
                            if (cmd == 1 || cmd == 0)
                            {
                                String jsonString = Encrypt.Decode(drexe.message);
                                if (jsonString.Length > 5)
                                {
                                    ProgramVars.siteClasses = JsonConvert.DeserializeObject<List<SiteClass>>(jsonString);
                                }
                                Forms.main.Invoke(new MethodInvoker(delegate ()
                                {
                                    UrlUtilityForm form2 = new UrlUtilityForm();
                                    form2.Show();
                                    CoreSystem.resize_window();
                                    isUtilOpen = true;
                                }));
                            }
                            else
                            {
                                Forms.main.Invoke(new MethodInvoker(delegate ()
                                {
                                    UrlUtilityForm.LoginDialogInstance.populateList();
                                }));
                            }
                        }

                    }
                    break;
                case 3:
                    DefaultResponse defRes = JsonConvert.DeserializeObject<DefaultResponse>(value);
                    if (cmd == 3)
                    {
                        String jsonStringx = Encrypt.Decode(defRes.message);
                        if (jsonStringx.Length > 5)
                        {
                            ProgramVars.chatList = JsonConvert.DeserializeObject<List<ChatResponse>>(jsonStringx);
                        }
                        Forms.main.Invoke(new MethodInvoker(delegate ()
                        {
                            if (!Forms.chat.IsDisposed)
                            {
                                Forms.chat.StartPosition = FormStartPosition.Manual;
                                Forms.chat.Location = new Point(Screen.PrimaryScreen.WorkingArea.Width - Forms.chat.Width,
                                                       Screen.PrimaryScreen.WorkingArea.Height - Forms.chat.Height);
                                Forms.chat.Show();
                            }
                            else
                            {
                                Forms.chat = new ChatWindow();
                                Forms.chat.StartPosition = FormStartPosition.Manual;
                                Forms.chat.Location = new Point(Screen.PrimaryScreen.WorkingArea.Width - Forms.chat.Width,
                                                       Screen.PrimaryScreen.WorkingArea.Height - Forms.chat.Height);
                                Forms.chat.Show();
                                chatLoaded = false;
                            }
                            Forms.chat.loadAll();
                            if (CoreSystem.startedToSurf)
                            {
                                CoreSystem.resize_window();
                            }
                        }));
                    }
                    if (cmd == 0)
                    {
                        if (CoreSystem.chatEnabled)
                        {
                            Forms.main.Invoke(new MethodInvoker(delegate ()
                            {
                                if (!Forms.chat.IsDisposed)
                                {
                                    Forms.chat.StartPosition = FormStartPosition.Manual;
                                    Forms.chat.Location = new Point(Screen.PrimaryScreen.WorkingArea.Width - Forms.chat.Width,
                                                           Screen.PrimaryScreen.WorkingArea.Height - Forms.chat.Height);
                                    Forms.chat.Show();
                                }
                                else
                                {
                                    Forms.chat = new ChatWindow();
                                    Forms.chat.StartPosition = FormStartPosition.Manual;
                                    Forms.chat.Location = new Point(Screen.PrimaryScreen.WorkingArea.Width - Forms.chat.Width,
                                                           Screen.PrimaryScreen.WorkingArea.Height - Forms.chat.Height);
                                    Forms.chat.Show();
                                    chatLoaded = false;
                                }
                                String jsonStringx = Encrypt.Decode(defRes.message);
                                if (jsonStringx.Length > 5)
                                {
                                    ProgramVars.chatList = JsonConvert.DeserializeObject<List<ChatResponse>>(jsonStringx);
                                }
                                CoreSystem.canSendChat = true;
                                Forms.chat.loadAll();
                            }));
                        }
                    }
                    break;
                default:
                    DefaultResponse drxz = JsonConvert.DeserializeObject<DefaultResponse>(value);
                    if (drxz != null)
                    {
                        MessageBox.Show(drxz.message);
                    }
                    break;
            }
            this.Refresh();

        }

        private void myurls_Click(object sender, EventArgs e)
        {
            if (Forms.util.Visible)
            {
                Forms.util.Hide();
                CoreSystem.resize_window();
            }
            else
            {
                if (!isUtilOpen)
                {
                    this.SendMessage("", Module.SITES, cmd.cmd0);
                }
            }
            
        }

        private void buymins_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.autosurf-traffic-exchange.com/Buy-Minutes?user="+ LoginDialog.username);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!chatLoaded)
            {
                chatLoaded = true;
                this.SendMessage("", Module.CHAT, cmd.cmd2);
            }

            
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Function not implemented!");
        }
    }
}
