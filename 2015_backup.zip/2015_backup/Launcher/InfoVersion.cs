﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Launcher
{
    class InfoVersion
    {
        public static int version = 1002;
    }
}
